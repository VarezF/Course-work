#include "ConnectFour.h"

void init_board(Cell board[][MAX_COL], int rows, int cols)
{
	int row_index = 0, col_index = 0;

	for (; row_index < rows; ++row_index)
	{
		for (col_index = 0; col_index < cols; ++col_index)
		{
			board[row_index][col_index].color = '\0';
			board[row_index][col_index].isOccupied = FALSE;
			board[row_index][col_index].place.row = row_index;
			board[row_index][col_index].place.col = col_index;
		}
	}
}