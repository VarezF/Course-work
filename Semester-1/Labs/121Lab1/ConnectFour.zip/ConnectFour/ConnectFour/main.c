// Complete the game of Connect Four from this starter code to recieve
// bonus points!

#include "ConnectFour.h"

int main(void)
{
	Cell board[MAX_ROW][MAX_COL] = { {/*row 0*/{'\0', FALSE, {0, 0}}} };

	init_board(board, MAX_ROW, MAX_COL);

	return 0;
}