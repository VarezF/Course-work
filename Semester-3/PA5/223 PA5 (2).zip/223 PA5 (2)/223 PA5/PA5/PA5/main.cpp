#include "Simulation.h"


int main() {
	Simulation simulation(0);

	simulation.start();
	
	return 0;
}